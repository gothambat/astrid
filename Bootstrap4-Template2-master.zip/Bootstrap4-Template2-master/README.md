# Bootstrap4-Template2
This template is designed and developed using Bootstrap 4 with HTML and CSS.  
It supports responsive layout which makes the template render well on various devices.  
Parallax and animation effects are involved in the template.

## Sreenshots
### Fullscreen on desktop 
- Fullpage
![](https://github.com/fanyuR/Bootstrap4-Template2/blob/master/demo%20img/demo1.png?raw=true)  

- Animation effets
![](https://github.com/fanyuR/Bootstrap4-Template2/blob/master/demo%20img/demo2.gif?raw=true)

### Responsive layout

![](https://github.com/fanyuR/Bootstrap4-Template2/blob/master/demo%20img/demo3.gif?raw=true)
